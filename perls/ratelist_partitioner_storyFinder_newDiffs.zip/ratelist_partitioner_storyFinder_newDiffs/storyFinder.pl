#!/usr/bin/perl
  use strict;
  use warnings;

# collect user input

my $newData=$ARGV[0]; # new raw tweets
my $refEntropy=$ARGV[1]; # output "/users/.../_entropy.csv" from the last reference run
my $refValence=$ARGV[2];
my $workingRoot=$ARGV[3]; # directory and "stem" for the new data, e.g. /users/a/r/areagan/twitter-story-finder/14.03.13/01

my @folders=split("\/",$workingRoot);
my $dataRoot=join("\/",@folders[0..scalar(@folders)-3]);

my $MTFILE=$dataRoot."\/labMT1\.txt";
my $compEntropy=$workingRoot."\_entropy\.csv";
my $compValence=$workingRoot."\_valence\.csv";
my $compCounts=$workingRoot."\_counted\.csv";
my $compRawPartition=$workingRoot."\_rawPartition.txt";
my $compAveValence=$workingRoot."\_aveVal\.txt";
my $compAveEntropy=$workingRoot."\_aveEnt\.txt";
my $refEntropyTimeseries=$refEntropy;
my $refValenceTimeseries=$refValence;
my $N=10;

my $space=" ";
my $comma="\,";
my $quote="\"";
my $newline="\n";
my $line;
my $i;
my $num;

# generate reference text file paths
$refEntropyTimeseries = "\/Users\/storyfinder\/data\/entropy\_timeseries\.csv";
$refValenceTimeseries = "\/Users\/storyfinder\/data\/valence\_timeseries\.csv";

# run partitioner, compute comparison entropy and valence
system("perl ratelist\_Partitioner\_phraseAmbience\.pl \"".$newData."\" \"".$workingRoot."\" ".$N." \"".$MTFILE."\"");
system("perl counts2\_GLentropyVlength\.pl \"".$compCounts."\" \"".$compEntropy."\"");

# shift recent hour against previous (held in the reference directory)
system("perl shift\_phrases\.pl \"".$refEntropy."\" \"".$compEntropy."\" \"".$workingRoot."\"");
system("perl shift\_phrases\_valence\.pl \"".$refValence."\" \"".$compValence."\" \"".$workingRoot."\"");

# copy current data over to the reference directory
system("cp ".$compEntropy." ".$refEntropy);
system("cp ".$compValence." ".$refValence);

# append comp timeseries with the current comp value
system("cat ".$compAveEntropy." >> ".$refEntropyTimeseries);
system("cat ".$compAveValence." >> ".$refValenceTimeseries);
