#!/usr/bin/perl
use strict;
use warnings;


# collect user input
my $geoFile=$ARGV[0];
my $labMTFile=$ARGV[1];
my $OUTFILE=$ARGV[2];
my $MT2FILE=$ARGV[3];

# initializations
my $newline="\n";
my $colon="\:";
my $comma="\,";
my $space=" ";
my $tab="\t";
my $quote="\"";
my $star="\*";
my $semicolon="\;";
my $line;
my $phrase;
my $word;
my %labMTHash;
my %phraseHash;
my $labMTScore;
my $numWords;
my @labInfo;
my $index; 
my $val;
my @lineInfo;
my $count;
my $clause;
my @words;
my $totalCount;
my $length;
my $order;
my $freq;
my $phraseVal;
my $MTCOUNT;

open my $labFile,'<', $labMTFile;
while($line =<$labFile>){
    @labInfo = split(/\t/,$line);
    $word = $labInfo[0];
    $index = $labInfo[1];
    $val = $labInfo[2];    
    @{$labMTHash{$word}} = ($index,$val); 
}
close $labFile;

my $replace= " ";
open my $tweetFile,'<',$geoFile;
while ($line=<$tweetFile>){
    @lineInfo = split(/\t/,$line);
    $phrase = $lineInfo[0];
    $count = $lineInfo[1];
    $clause = $lineInfo[2];
    $clause =~ s/$phrase/$replace/i;
    $clause =~ s/\;/$replace/gi;
    $clause =~ s/[ ]+/$replace/gi;
    $clause =~ s/^ //gi;
    $clause =~ s/ $//gi;
    @words = split(" ",$clause);
    $labMTScore = 0;
    $numWords = 0;
    $totalCount+=$count;
    if (defined ${$phraseHash{$phrase}}{"COUNTS"}){
	${$phraseHash{$phrase}}{"COUNTS"}+=$count;
    }
    else{
	${$phraseHash{$phrase}}{"COUNTS"}=$count;
    }
    foreach $word (@words){
	if (defined $labMTHash{$word}){
	    if (defined ${$phraseHash{$phrase}}{$word}){
		${$phraseHash{$phrase}}{$word} += $count;
	    }
	    else {
		${$phraseHash{$phrase}}{$word} = $count;
	    }
	}
    }   
}
close $tweetFile;

open(OUTFILE, '>',$OUTFILE);
open(MTOUTFILE,'>',$MT2FILE);
print MTOUTFILE "phrase\,count\,valence\,length\,order".$newline;
foreach $phrase (keys %phraseHash){
    print OUTFILE $phrase."\n";
    $freq=${$phraseHash{$phrase}}{"COUNTS"};
    $order=scalar(split($space,$phrase));
    $length=length($phrase)-$order+1;
    $phraseVal=0;
    $MTCOUNT=0;
    foreach $word (keys %{$phraseHash{$phrase}}){
	if (!($word eq "COUNTS")){
	    $phraseVal+=${$labMTHash{$word}}[1]*${$phraseHash{$phrase}}{$word};
	    $MTCOUNT+=${$phraseHash{$phrase}}{$word};
	    print OUTFILE ${$labMTHash{$word}}[0]."\t".${$phraseHash{$phrase}}{$word}."\n";
	}
    }
    
    $phrase=$quote.$phrase.$quote;
    if ($MTCOUNT){;
	$phraseVal/=$MTCOUNT;
	print MTOUTFILE $phrase.$comma.$freq.$comma.$phraseVal.$comma.$length.$comma.$order.$newline;
    }    
    print OUTFILE "\n";   
}
close(MTOUTFILE);
close(OUTFILE);
