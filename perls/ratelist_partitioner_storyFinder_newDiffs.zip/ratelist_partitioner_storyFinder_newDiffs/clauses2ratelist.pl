#!/usr/bin/perl
  use strict;
  use warnings;

# collect user input
my $file=$ARGV[0]; # clause input file path
my $fullLoc=$ARGV[1]; # output file path
my $N=$ARGV[2]; # max length phrase to get data on

# initializations
my $space=" ";
my $newline="\n";
my $star="\*";
my $colon="\:";
my $comma="\,";
my $quote="\"";
my $semicolon="\;";
my $line;
my $order;
my $phrase;
my $lastPhrase;
my $weight;
my $count;
my $sequence;
my $length;
my $n;
my @subterms;
my $neighborhood;
my $subsequence;
my $rate;
my $checkrate;
my $r=1;
my $currentOrder;
my $printCount;
my $countval;
my $hood;
my $maxweight;
my $newweight;
my %data;
my %lastdata;
my %hoodweights;
my $i;
my @terms;
my $insertion;
my $page;

@{$lastdata{$star}}=($star,0);
for ($currentOrder=1;$currentOrder<=$N;$currentOrder++){
    
    # find neighborhoods for order
    open $page,'<',$file;
    while ($line=<$page>){
	if ($line=~m/(.*?)$comma(.*?)$comma$quote(.*?)$quote$newline/gi){ 
	    $length=$1;
	    $count=$2;
	    $sequence=$3;
	    if ($currentOrder<=$length){
		@terms=split($space,$sequence);
		for ($n=0; $n<$length-$currentOrder+1; $n++){
		    @subterms=@terms[$n..$currentOrder-1+$n];
		    $subsequence=join($space, @subterms);
		    if ($n == 0 || $n == $length-$currentOrder){
			$r=0;
		    }
		    if ($currentOrder == $length){
			$r=-1;
		    }
		    $countval=$count*$currentOrder/(2**($currentOrder+$r));
		    $r=1;
		    for ($i=0; $i<$currentOrder; $i++){
			if ($currentOrder-1 == 0){
			    $neighborhood=$star;
			}
			if ($i == 0 && $currentOrder-1){
			    $neighborhood=join($space,@subterms[$i..$currentOrder-2]);
			}
			if ($i == $currentOrder-1 && $currentOrder-1){
			    $neighborhood=join($space,@subterms[1..$i]);
			}
			if ($i > 0 && $i < $currentOrder-1){
			    $neighborhood=join($space,@subterms[0..$currentOrder-($i+2),$currentOrder-$i..$currentOrder-1]);
			}
			if (defined $hoodweights{$neighborhood}){
			    $hoodweights{$neighborhood}+=$countval;
			}
			else{
			    $hoodweights{$neighborhood}=$countval;
			}
		    }	    
		}	    
	    }	    	    
	}
    }
    close $page;

    if (!($currentOrder==1)){
	%lastdata=%data;
	undef %data;
	my %data;
    }

    open $page,'<',$file;
    while ($line=<$page>){
	if ($line=~m/(.*?)$comma(.*?)$comma$quote(.*?)$quote$newline/gi){ 
	    $length=$1;
	    $count=$2;
	    $sequence=$3;
	    if ($currentOrder<=$length){
		@terms=split($space,$sequence);
		for ($n=0; $n<$length-$currentOrder+1; $n++){
		    @subterms=@terms[$n..$currentOrder-1+$n];
		    $subsequence=join($space, @subterms);
		    if ($currentOrder==1){
			$lastPhrase=$star;
		    }
		    else{
			$lastPhrase=join($space,@subterms[0..scalar(@subterms)-2]);
		    }
		    if (defined $lastdata{$lastPhrase}){
			if ($n == 0 || $n == $length-$currentOrder){
			    $r=0;
			}
			if ($currentOrder == $length){
			    $r=-1;
			}
			$countval=$count*$currentOrder/(2**($currentOrder+$r));
			$r=1;
			if (defined $data{$subsequence}){
			    ${$data{$subsequence}}[1]+=$countval;
			    
			}
			else{
			    @{$data{$subsequence}}=($subsequence,$countval);
			}		    		    
		    }		    
		}	    
	    }	    	    
	}
    }
    close $page;

    if ($currentOrder==1){
	open(OUTFILE,'>',$fullLoc);
    }
    else{
	open(OUTFILE,'>>',$fullLoc);
    }
    # compute likelihoods, remove those that have dropped & print rising ones
    foreach $phrase (reverse sort {${$data{$a}}[1] <=> ${$data{$b}}[1]} keys %data){
	@terms=split($space,$phrase);
	$hood=$phrase;
	$maxweight=${$data{$phrase}}[1];
	for ($i=0; $i<$currentOrder; $i++){
	    if ($currentOrder-1 == 0){
		$neighborhood=$star;
	    }
	    if ($i == 0 && $currentOrder-1){
		$neighborhood=join($space,@terms[$i..$currentOrder-2]);
	    }
	    if ($i == $currentOrder-1 && $currentOrder-1){
		$neighborhood=join($space,@terms[1..$i]);
	    }
	    if ($i > 0 && $i < $currentOrder-1){
		$neighborhood=join($space,@terms[0..$currentOrder-($i+2),$currentOrder-$i..$currentOrder-1]);
	    }
	    $newweight=$hoodweights{$neighborhood};
	    if ($newweight > $maxweight){
		$maxweight=$newweight;
		$hood=$neighborhood;
	    }	    
	}
	$rate=${$data{$phrase}}[1]/$maxweight;
	$printCount=${$data{$phrase}}[1];
	if ($currentOrder==1){
	    $checkrate=0;
	}
	else{
	    $lastPhrase=join($space, @terms[0..scalar(@terms)-2]);
	    if (defined $lastdata{$lastPhrase}){
		$checkrate=${$lastdata{$lastPhrase}}[1];  
	    }
	    else{
		$checkrate=2;
	    }
	}
	if ($checkrate<=$rate){
	    @{$data{$phrase}}=($phrase,$rate,$printCount);
	    print OUTFILE $quote.$phrase.$quote.$comma.join($comma,@{$data{$phrase}}[1..2]).$newline;
	}
	else{
	    undef $data{$phrase};
	}
    }
    close(OUTFILE);
    undef %hoodweights;
    my %hoodweights;
}
